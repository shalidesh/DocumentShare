import os
import sys
from src.logger import logging
from src.exception import CustomException
import pandas as pd
from dataclasses import dataclass
import numpy as np


class EighthCriteria:
    def __init__(self,crib_dishouner8:pd.DataFrame):
        self.crib_dishouner8 = crib_dishouner8


    def calculate_eighth_score(self):

        logging.info("Entered the calculate eighth criteria score calculation")
        
        try:
            count_dishonor_cheque = self.crib_dishouner8.Cheque_Number.count()

            if count_dishonor_cheque == 0:
                crib_sc = 1
            elif 1 <= count_dishonor_cheque < 10:
                crib_sc = 0.5
            elif 10 <= count_dishonor_cheque < 20:
                crib_sc = -0.5
            elif 20 <= count_dishonor_cheque < 50:
                crib_sc = -0.75
            elif 50 <= count_dishonor_cheque:
                crib_sc = -1.5

            score=crib_sc*0.1

            return(
                score
            )
        except Exception as e:
            raise CustomException(e,sys)
        

