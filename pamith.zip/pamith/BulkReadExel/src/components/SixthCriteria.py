import os
import sys
from src.logger import logging
from src.exception import CustomException
import pandas as pd
from dataclasses import dataclass
import numpy as np
import time


class SixthCriteria:
    def __init__(self,crib_status:pd.DataFrame,current_liabillities:pd.DataFrame):
        
        
        self.crib_status = crib_status
        self.current_liabillities= current_liabillities
        

    def calculate_sixth_score(self):

        logging.info("Entered the calculate sixth criteria score calculation")
        
        try:
            
            filtered = self.current_liabillities[self.current_liabillities['OWNERSHIP'] == 'As Borrower']

            if not filtered.empty:

                total_granted_amount = filtered['TOT_AMOUNT_GRANTED'].sum()

                facility_amount = self.crib_status['FACILITY_AMOUNT']
                score = facility_amount.div(total_granted_amount) * 100

                # Extract the scalar value from the Series
                score_value = score.values[0]

                # Assuming 'score' is a column in your DataFrame
                if score_value <= 100:
                    crib_sc = 1
                elif 100 < score_value <= 150:
                    crib_sc = 0.75
                elif 150 < score_value <= 200:
                    crib_sc = 0.5
                elif 200 < score_value <= 250:
                    crib_sc = 0.0
                else:
                    crib_sc = -0.5

                score=crib_sc*0.1

            else:
                score=1

            return(
                score
            )
        except Exception as e:
            raise CustomException(e,sys)
        
