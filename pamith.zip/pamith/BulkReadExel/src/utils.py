
def dataColumnsCheck():
    return True